package com.employeeTravel.main.service;

import com.employeeTravel.main.domain.EmployeeDetails;

public interface EmployeeDetailsServiceInterface {
	public EmployeeDetails showEmployeeDetails(int loginId);

}
