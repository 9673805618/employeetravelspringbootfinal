package com.employeeTravel.main.repository;

public interface DocumentsDetailsRepositoryInterface {

}
