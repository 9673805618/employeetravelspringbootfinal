package com.employeeTravel.main.service;

public interface SlabDetailsServiceInterface {

}
