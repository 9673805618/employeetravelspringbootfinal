package com.employeeTravel.main.repository;

public class DocumentsDetailsRepository implements DocumentsDetailsRepositoryInterface {

}
